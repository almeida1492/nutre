package com.example.henriqueribeirodealmeida.nutre.Fragments;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.telecom.Call;
import android.widget.DatePicker;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DatePickerFragment extends DialogFragment {

    private final static String DATETIMEKEY = "com.example.henriqueribeirodealmeida.nutre.datetimekey";
    String calendarDate;

    private DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int day) {
            Date d = new Date(year, month, day);
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormatter.format(d);

            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
            SharedPreferences.Editor editor;
            editor = prefs.edit();
            editor.putString(DATETIMEKEY, strDate);
            editor.apply();
            getActivity().recreate();
        }
    };

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        int y,m,d;
        calendarDate = prefs.getString(DATETIMEKEY, null);
        if (calendarDate!=null){
            try{
                y = Integer.parseInt(calendarDate.substring(0,40).replaceAll("[^0-9]",""));
                m = Integer.parseInt(calendarDate.substring(4,7).replaceAll("[^0-9]",""));
                d = Integer.parseInt(calendarDate.substring(7,9).replaceAll("[^0-9]",""));
                return new DatePickerDialog(getActivity(), dateSetListener, y, m, d);
            }catch(IndexOutOfBoundsException e){
                return new DatePickerDialog(getActivity(), dateSetListener, year, month, day);
            }
        }
        return new DatePickerDialog(getActivity(), dateSetListener, year, month, day);
    }


}




